#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#La funcion import importa los datos necesarios de las librerias
import msvcrt
import random
from colorama import Fore

''' 
Este programa crea una lista de numeros aleatorios del 1 al 20, cuando llega al 0 se detiene y luego realiza operaciones como
calcular cuales son los numeros pares, los numeros impares, la longitud de la lista y el promedio
'''

#Se define la funcion lista() para almacenar los procesos del codigo
def lista():
    
    generar_color=random.choice([Fore.BLUE, Fore.CYAN, Fore.GREEN, Fore.LIGHTYELLOW_EX, Fore.LIGHTRED_EX, Fore.LIGHTMAGENTA_EX])
    
    #Se crea la lista vacia para comenzar a almacenar datos
    numeros = []
    
    #Se pone una condicion para que en caso de que el numero random sea 0 la lista deje de almacenar datos
    while True:
        dato1 = random.randint(0,21)
        if dato1 == 0:
            break
        numeros.append(dato1)
    print(generar_color, numeros)
    
    #Se muestra la longitud, la suma, el promedio, los numeros pares e impares de la lista
    print("La lonitud de la lista es: ", len(numeros))
    
    for pares in numeros:
        if pares % 2 == 0:
            print(f"{pares} Es un numero par")
        
        else:
            print(f"{pares} Es un numero impar")

    suma = sum(numeros)
    print("la suma de los datos es: ", suma)

    promedio = suma/len(numeros)
    print("El promedio es: ", promedio)
    
    #Se le da la opcion al usuario dde terminar o volver a generar el proceso
    print("¿Desea generar otra vez el proceso? s/n")
    
    respuesta = None
    
    while respuesta not in ["s", "n"]:
        respuesta = msvcrt.getwch()
    if respuesta == "s":
        lista()
    elif respuesta == "n":
        print("¡Gracias por usar el programa!")

if __name__ == "__main__":
   #Inicia el programa
    lista()

